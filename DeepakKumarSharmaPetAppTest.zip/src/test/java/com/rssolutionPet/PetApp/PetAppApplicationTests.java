package com.rssolutionPet.PetApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
