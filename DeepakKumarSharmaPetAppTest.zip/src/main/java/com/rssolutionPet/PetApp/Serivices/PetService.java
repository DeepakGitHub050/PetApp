package com.rssolutionPet.PetApp.Serivices;

import com.rssolutionPet.PetApp.Models.Pet;
import com.rssolutionPet.PetApp.Enum.PetStatus;
import com.rssolutionPet.PetApp.Repositories.PetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.rssolutionPet.PetApp.Enum.PetStatus.AVAILABLE;

@Service
public class PetService {
    @Autowired
    private PetRepository petRepository;

    public void savePetDetails(Pet pet) {
        petRepository.save(pet);
    }
    public List<Pet> getPetsByStatus(String status) {
        List<Pet> pets = petRepository.findAll();
        List<Pet> filteredPets = pets.stream().filter(p-> p.getStatus().equals(status))
                .toList();
        return filteredPets;
    }
}
