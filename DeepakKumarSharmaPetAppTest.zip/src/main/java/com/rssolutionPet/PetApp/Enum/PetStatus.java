package com.rssolutionPet.PetApp.Enum;

public enum PetStatus {
    AVAILABLE,PENDING,SOLD
}
