package com.rssolutionPet.PetApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetAppApplication.class, args);
	}

}
