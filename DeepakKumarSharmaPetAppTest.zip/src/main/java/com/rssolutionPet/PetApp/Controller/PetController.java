package com.rssolutionPet.PetApp.Controller;

import com.rssolutionPet.PetApp.Models.Pet;
import com.rssolutionPet.PetApp.Repositories.PetRepository;
import com.rssolutionPet.PetApp.Serivices.PetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class PetController {
    @Autowired
    private PetService petService;

    @GetMapping("/{status}")
    public ResponseEntity<List<Pet>> getPet(@PathVariable String status) {
        List<Pet> pets = petService.getPetsByStatus(status);
        if(pets == null || pets.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(pets, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Pet> postPet(@RequestBody Pet pet) {
        petService.savePetDetails(pet);
        return new ResponseEntity<>(pet, HttpStatus.CREATED);
    }
}
